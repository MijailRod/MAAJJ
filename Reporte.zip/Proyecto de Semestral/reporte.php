
<?php
//Incluimos la plantilla
	include 'Plantilla.php';
	//Agregamos la conexion
	require 'conexion.php';
	//la consulta de reporte
	$query = "SELECT id, fecha_de_report, titulo_repot, descricion, numero_repot, codig_dep  FROM reportes ";
//nos da el resultado de la consulta
	$resultado = $mysqli->query($query);
//para hacer llamado a la clase PDF
	$pdf = new PDF();
	//alias para el numero de paginas
	$pdf->AliasNbPages();
	//agramos paginas
	$pdf->AddPage();
//Los encabezados para el tabla
	$pdf->SetFillColor(232,232,232);
	//el Tipo de fuente
	$pdf->SetFont('Arial','B',14);
//la cel de la tabla
	$pdf->Cell(70,6,'Id',1,0,'C',1);
	$pdf->Cell(70,6,'Fecha de Reporte',1,0,'C',1);
	$pdf->Cell(70,6,'Titutlo',1,0,'C',1);
	$pdf->Cell(70,6,'Despcricion',1,0,'C',1);
	$pdf->Cell(70,6,'Numero de Reporte',1,0,'C',1);
	$pdf->Cell(70,6,'Codigo del Departamento',1,0,'C',1);

	$pdf->SetFont('Arial','',10);
//para ser un recorrido en la consulta que hagamos
	while($row = $resultado->fetch_assoc())
	{
		//datos de la consulta
		$pdf->Cell(70,6,utf8_decode($row['id']),1,0,'C');
		$pdf->Cell(70,6,utf8_decode($row['fecha_de_report']),1,0,'C');
		$pdf->Cell(70,6,utf8_decode($row['titulo_repot']),1,0,'C');
			$pdf->Cell(70,6,utf8_decode($row['descricion']),1,0,'C');
				$pdf->Cell(70,6,utf8_decode($row['numero_repot']),1,0,'C');
					$pdf->Cell(70,6,utf8_decode($row['codig_dep']),1,0,'C');
	}
	//cerramos
	$pdf->Output();
?>

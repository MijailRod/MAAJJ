
<?
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'bd_pf_ds7');
     //servidor, usuario, contraseña,base de datos
		 $link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_DATABASE);

		 if($link === false){
		     die("ERROR: Could not connect. " . mysqli_connect_error());
		 }
?>
//por Si acaso
//*$mysqli = new mysqli("localhost","root","","bd_pf_ds7");

if(mysqli_connect_errno()){

	echo 'Conexion Fallida : ', mysqli_connect_error();
	exit();
}*//

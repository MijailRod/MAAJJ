
<?php
	include 'Plantilla.php';
	require 'conexion.php';
	//la consulta de reporte
	$query = "SELECT id, fecha_de_report, titulo_repot, descricion, numero_repot, codig_dep  FROM reportes ";
	$resultado = $mysqli->query($query);

	$pdf = new PDF();
	$pdf->AliasNbPages();
	$pdf->AddPage();

	$pdf->SetFillColor(232,232,232);
	$pdf->SetFont('Arial','B',14);

	$pdf->Cell(70,6,'Id',1,0,'C',1);
	$pdf->Cell(70,6,'Fecha de Reporte',1,0,'C',1);
	$pdf->Cell(70,6,'Titutlo',1,0,'C',1);
	$pdf->Cell(70,6,'Despcricion',1,0,'C',1);
	$pdf->Cell(70,6,'Numero de Reporte',1,0,'C',1);
	$pdf->Cell(70,6,'Codigo del Departamento',1,0,'C',1);

	$pdf->SetFont('Arial','',10);

	while($row = $resultado->fetch_assoc())
	{
		$pdf->Cell(70,6,utf8_decode($row['id']),1,0,'C');
		$pdf->Cell(70,6,utf8_decode($row['fecha_de_report']),1,0,'C');
		$pdf->Cell(70,6,utf8_decode($row['titulo_repot']),1,0,'C');
			$pdf->Cell(70,6,utf8_decode($row['descricion']),1,0,'C');
				$pdf->Cell(70,6,utf8_decode($row['numero_repot']),1,0,'C');
					$pdf->Cell(70,6,utf8_decode($row['codig_dep']),1,0,'C');
	}
	$pdf->Output();
?>
